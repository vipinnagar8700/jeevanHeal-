export { default as IMG01} from '../../../../assets/images/doctors/doctor-thumb-01.jpg';
export { default as IMG02} from '../../../../assets/images/doctors/doctor-thumb-02.jpg';
export { default as IMG03} from '../../../../assets/images/doctors/doctor-thumb-03.jpg';
export { default as IMG04} from '../../../../assets/images/doctors/doctor-thumb-04.jpg';
export { default as IMG05} from '../../../../assets/images/doctors/doctor-thumb-06.jpg';
export { default as Slide1} from '../../../../assets/images/slide1.png';
export { default as Slide2} from '../../../../assets/images/slide2.png';